<?php
interface ExceptionWithThrowable extends \Throwable
{
}

