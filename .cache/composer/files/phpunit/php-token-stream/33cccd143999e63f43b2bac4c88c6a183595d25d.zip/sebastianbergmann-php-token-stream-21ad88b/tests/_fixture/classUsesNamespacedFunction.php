<?php
namespace foo;

use function bar\baz;

class Foo
{
}